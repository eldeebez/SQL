USE UNIRANK


CREATE TABLE Client(
	ClientId INT PRIMARY KEY,
	ClientName VARCHAR(100) NOT NULL,
	Addres VARCHAR (200),
	Email VARCHAR(50) UNIQUE,
	Phone INT,
	Business VARCHAR(100)

);



CREATE TABLE Project(
	ProjectId INT PRIMARY KEY,
	Description_ VARCHAR(200),
	StartDate DATE,
	PlannedEndDate DATE,
	ActualEndDate DATE,
		CONSTRAINT CHKENDDATE CHECK (ActualEndDate > PlannedEndDate),
	Budget INT ,
		CONSTRAINT CHKP CHECK (Budget > 0),
	ClientId INT FOREIGN KEY REFERENCES Client
);



CREATE TABLE Department(
	DepartmentNo INT PRIMARY KEY,
	DepartmentName VARCHAR(100) NOT NULL
);



CREATE TABLE Employee(
	EmployeeNo INT PRIMARY KEY,
	EmployeeName varchar(100) NOT NULL,
	Job VARCHAR(100),
	Salary INT,
		CONSTRAINT CHKSALARY CHECK (Salary > 1700),
	DepartmentNo INT FOREIGN KEY REFERENCES Department
);


CREATE TABLE EmployeeProjectTask(
	ProjectId INT,
	EmployeeNo INT, 
	StartDate DATE,
	EndDate DATE,
	Task VARCHAR(100),
	Status_ VARCHAR(30),
	PRIMARY KEY (EmployeeNo,ProjectId),
	FOREIGN KEY (ProjectId) REFERENCES Project(ProjectId),
	FOREIGN KEY (EmployeeNo) REFERENCES Employee(EmployeeNo),
);

