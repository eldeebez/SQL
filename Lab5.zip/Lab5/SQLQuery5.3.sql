USE UNIRANK 


SELECT EmployeeName
FROM EMPLOYEE 
WHERE EmployeeName LIKE 'J%';

SELECT EmployeeName
FROM Employee
WHERE LEN(EmployeeName) = (
    SELECT MAX(LEN(EmployeeName))
    FROM Employee
);


SELECT distinct DepartmentName, EmployeeName, Salary
FROM Department, Employee
ORDER BY Salary DESC;
