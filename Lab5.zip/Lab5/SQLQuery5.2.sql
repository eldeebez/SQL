USE UNIRANK

INSERT INTO Client (ClientId, ClientName, Addres, Email, Phone, Business)
VALUES
    (1, 'great Technology', '10 Grunwaldzki, Wroclaw', 'great@example.com', 1234567890, 'Software Development'),
    (2, 'good Industries', '80 sucha, Warsaw', 'good@example.com', 9876543210, 'Consulting Services');

INSERT INTO Project (ProjectId, Description_, StartDate, PlannedEndDate, ActualEndDate, Budget, ClientId)
VALUES
    (1, 'Website Redesign', '2024-05-01', '2024-06-01', '2024-06-15', 5000, 1),
    (2, 'Marketing Campaign', '2024-06-01', '2024-07-01', '2024-07-15', 7000, 2);

INSERT INTO Department (DepartmentNo, DepartmentName)
VALUES
    (101, 'Marketing'),
    (102, 'Engineering');

INSERT INTO Employee (EmployeeNo, EmployeeName, Job, Salary, DepartmentNo)
VALUES
    (1001, 'MARK Smith', 'Software Engineer', 5000, 102),
    (1002, 'Emily Johnson', 'Marketing Specialist', 4500, 101);

INSERT INTO EmployeeProjectTask (ProjectId, EmployeeNo, StartDate, EndDate, Task, Status_)
VALUES
    (1, 1001, '2024-05-01', '2024-06-01', 'Frontend Development', 'In Progress'),
    (2, 1002, '2024-06-01', '2024-07-01', 'Content Creation', 'Completed');
