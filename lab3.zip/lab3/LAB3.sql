CREATE DATABASE UNIRANK;
GO
USE UNIRANK;
GO
CREATE TABLE Country(
id INT PRIMARY KEY ,
country_name VARCHAR(50),
);
GO
CREATE TABLE UNIVERSITY(
id INT PRIMARY KEY,
Country_id INT FOREIGN KEY REFERENCES Country(id),
university_came UNIQUE VARCHAR(50),

);
GO
CREATE TABLE Ranking_System(
id INT PRIMARY KEY,
system_name VARCHAR(50),
);
GO
CREATE TABLE Ranking_Criteria(
id INT PRIMARY KEY,
ranking_system_id INT FOREIGN KEY REFERENCES Ranking_system(id),
criteria_name VARCHAR(50),
);
GO
CREATE TABLE University_Ranking_Year(
university_id INT FOREIGN KEY REFERENCES University(id),
ranking_criteria_id INT FOREIGN KEY REFERENCES Ranking_Criteria(id),
years INT ,
score INT,
);
GO
INSERT INTO Country (id, country_name)
VALUES
	(1,'POLAND'),
	(2,'USA'),
	(3,'UK'),
	(4,'EGYPT'),
	(5,'SPAIN');

GO
INSERT INTO UNIVERSITY(id,Country_id,university_came)
VALUES
	(1,1,'POLITECHNIKA WROCLAWSKA'),
	(4,4,'CAIRO UNIVERSITY'),
	(5,5,'BARCELONA UNIVERSITY'),
	(2,2,'STANFORD UNIVERSITY'),
	(3,3,'LONDON UNIVERSITY');

INSERT INTO University_Ranking_Year(university_id,ranking_criteria_id,years,score)
VALUES
	(1,1,2010,300),
	(2,2,2010,100),
	(3,3,2010,70),
	(4,4,2010,500),
	(5,5,2010,250);
GO
INSERT INTO Ranking_Criteria(id,ranking_system_id,criteria_name)
VALUES
	(1,1,'QUALITY-CITATION'),
	(2,2,'QUALITY-CITATION'),
	(3,3,'QUALITY-CITATION'),
	(4,4,'QUALITY-CITATION'),
	(5,5,'QUALITY-CITATION');
GO
INSERT INTO Ranking_System(id,system_name)
VALUES
	(1,'WORKD RANKING'),
	(2,'WORKD RANKING'),
	(3,'WORKD RANKING'),
	(4,'WORKD RANKING'),
	(5,'WORKD RANKING');

GO
ALTER TABLE UNIVERSITY_RANKING_YEAR
ADD years INT, score INT
