USE UNIRANK;

CREATE TABLE University_Year(
		university_year_id INT PRIMARY KEY,
		university_id INT FOREIGN KEY REFERENCES University(id),
		yearss INT,
		CHECK (YEARSS > 2000),
		num_student INT,
		CHECK (num_student BETWEEN 0 AND 10000),
		student_staff_ratio FLOAT,
		CHECK (student_staff_ratio > 0)
);







